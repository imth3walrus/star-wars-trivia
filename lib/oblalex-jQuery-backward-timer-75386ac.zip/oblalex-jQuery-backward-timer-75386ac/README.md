jQuery-backward-timer
=====================

Please, visit [plugin's page](http://oblalex.github.io/jQuery-backward-timer/)
for description, documentation and examples.
